package com.example.dlapd.seoulcarmap;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.places.AutocompleteFilter;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlaceAutocomplete;
import com.google.android.gms.location.places.ui.PlaceAutocompleteFragment;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;

import java.io.IOException;
import java.util.List;

public class AddingActivity2 extends AppCompatActivity implements OnMapReadyCallback {

    private double lat;
    private double lon;
    GoogleMap map2;
    private int PLACE_AUTOCOMPLETE_REQUEST_CODE = 200;
    private int REQUEST_CODE_PERMISSIONS = 2000;
    Marker marker;
    String address;
    TextView show_now;
    private FusedLocationProviderClient mFusedLocationClient;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adding2);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.lab2_map);
        mapFragment.getMapAsync(AddingActivity2.this);

        PlaceAutocompleteFragment autocompleteFragment = (PlaceAutocompleteFragment)
                getFragmentManager().findFragmentById(R.id.place_autocomplete_fragment2);
        EditText etPlace = (EditText) autocompleteFragment.getView().findViewById(R.id.place_autocomplete_search_input);
        ImageButton back_btn = (ImageButton)findViewById(R.id.back_btn);
        ImageButton ivPlace = (ImageButton) autocompleteFragment.getView().findViewById(R.id.place_autocomplete_search_button);
        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);


        back_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        etPlace.setHint("추가할 주차장 위치를 검색         ");
        TranslateAnimation ani = new TranslateAnimation(
                Animation.RELATIVE_TO_SELF, 1.0f,
                Animation.RELATIVE_TO_SELF, -1.0f,
                Animation.RELATIVE_TO_SELF, 0.0f,
                Animation.RELATIVE_TO_SELF, 0.0f);
        ani.setDuration(6000);
        ani.setRepeatMode(Animation.RESTART);
        ani.setRepeatCount(Animation.INFINITE);
        etPlace.startAnimation(ani);

        etPlace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                findPlace(view);
            }
        });

        ivPlace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                findPlace(view);
            }
        });
    }





    public void findPlace(View view) {
        try {
            AutocompleteFilter typeFilter = new AutocompleteFilter.Builder().setTypeFilter(AutocompleteFilter.TYPE_FILTER_NONE).setCountry("KR").build();
            Intent intent =
                    new PlaceAutocomplete.IntentBuilder(PlaceAutocomplete.MODE_FULLSCREEN)
                            .setFilter(typeFilter)
                            .build(this);
            startActivityForResult(intent, PLACE_AUTOCOMPLETE_REQUEST_CODE);
        } catch (GooglePlayServicesRepairableException e) {
            // TODO: Handle the error.
        } catch (GooglePlayServicesNotAvailableException e) {
            // TODO: Handle the error.
        }


    }

    @Override
    public void onMapReady(GoogleMap googleMap) {

        map2 = googleMap; //googleMap 객체를 얻음.

        LatLng latLng = new LatLng(37.566643, 126.978279); // 지도내의 특정위치를 LatLng 객체로 표현. LatLng 객체에 위도, 경도를 매개변수로 줌.

        CameraPosition position = new CameraPosition.Builder().target(latLng).zoom(16f).build(); // CameraPosition 클래스는 지도가 화면에 출력되기 위한 정보를
        // 가지는 클래스로 지도의 중심 위치를 target()함수로, 지도의 확대 수준을 zoom()함수로 지정. 이렇게 만들어진 CameraPosition 을 GoogleMap 의 movecCameraag 함수의
        // 매개변수로 지정하면 CameraPosition 의 정보대로 지도에 표시된다. 위의 코드는 LatLng 객체가 표현하는 위치에 확대 수준 16의 지도를 화면에 출력한다.
        map2.getUiSettings().setZoomControlsEnabled(true);
        map2.moveCamera(CameraUpdateFactory.newCameraPosition(position));
        // 내 위치 찍기 관련 영역
        map2.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            @Override
            public void onMapClick(LatLng latLng) {
                if(marker!=null)marker.remove();
                marker= map2.addMarker(new MarkerOptions().position(new LatLng(latLng.latitude,latLng.longitude)));
                Geocoder geocoder = new Geocoder(AddingActivity2.this);
                // 현재위치 주소얻기
                try {
                    lat=latLng.latitude;
                    lon=latLng.longitude;
                    address = geocoder.getFromLocation(latLng.latitude, latLng.longitude, 1).get(0).getAddressLine(0).toString(); /*위도, 경도값*/

                }
                catch (IOException e)
                {
                    e.printStackTrace();

                    // 실패할경우 이걸로 대체.
                }

                show_now = (TextView)findViewById(R.id.show_now);
                show_now.setText(address);





            }

        });

        ImageButton imageButton = (ImageButton)findViewById(R.id.check_btn);
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(AddingActivity2.this, AddingActivity.class);
                intent.putExtra("address",address);
                intent.putExtra("lat",lat);
                intent.putExtra("lon",lon);
                startActivity(intent);
                finish();}});
    }

    Marker marker2;
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PLACE_AUTOCOMPLETE_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                final Place place = PlaceAutocomplete.getPlace(this, data);

                if (marker2 != null) {
                    marker2.remove();
                }
                map2.moveCamera(CameraUpdateFactory.newLatLng(place.getLatLng()));
                MarkerOptions marker = new MarkerOptions();
                marker.icon(BitmapDescriptorFactory.fromResource(R.drawable.marker3));
                marker2 = map2.addMarker(marker.position(place.getLatLng()));



            }



        } else if (resultCode == PlaceAutocomplete.RESULT_ERROR) {
            Status status = PlaceAutocomplete.getStatus(this, data);
            // TODO: Handle the error.

        } else if (resultCode == RESULT_CANCELED) {
            // The user canceled the operation.
        }
    }

    public void OnLastLocationButtonClicked(View view) {
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.
                checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQUEST_CODE_PERMISSIONS);
            return;
        }

        mFusedLocationClient.getLastLocation().addOnSuccessListener(this, new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if (location != null) {
//                    MarkerOptions mymarker= new MarkerOptions();
//                    mymarker.icon(BitmapDescriptorFactory.fromResource(R.drawable.marker3));
//                    mymarker.title("현재 위치");
                    LatLng myLocation = new LatLng(location.getLatitude(), location.getLongitude());
//                    map.addMarker(mymarker.position(myLocation));
                    //map.addMarker(new MarkerOptions().position(myLocation).title("현재 위치").icon(BitmapDescriptorFactory.fromResource(R.drawable.marker3)));
                    map2.moveCamera(CameraUpdateFactory.newLatLng(myLocation));
                    map2.animateCamera(CameraUpdateFactory.zoomTo(16.0f));

                }
            }
        });
    }

}

