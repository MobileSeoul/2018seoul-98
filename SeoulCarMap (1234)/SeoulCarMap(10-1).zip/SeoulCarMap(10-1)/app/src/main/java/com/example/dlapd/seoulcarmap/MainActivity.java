package com.example.dlapd.seoulcarmap;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.Color;
import android.graphics.drawable.AnimatedVectorDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.RemoteException;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomSheetDialogFragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AlertDialog;
import android.text.Layout;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.example.dlapd.seoulcarmap.chat.MessageActivity;
import com.facebook.login.LoginManager;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.dynamic.zzn;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.places.AutocompleteFilter;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlaceAutocomplete;
import com.google.android.gms.location.places.ui.PlaceAutocompleteFragment;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;


import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.RuntimeRemoteException;
import com.google.android.gms.maps.model.internal.zzp;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.kakao.kakaonavi.KakaoNaviParams;
import com.kakao.kakaonavi.KakaoNaviService;
import com.kakao.kakaonavi.NaviOptions;
import com.kakao.kakaonavi.options.CoordType;
import com.kakao.kakaonavi.options.RpOption;
import com.kakao.kakaonavi.options.VehicleType;
import com.skt.Tmap.TMapTapi;

import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.view.Menu;
import android.view.MenuItem;

import org.w3c.dom.Text;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;
import java.util.zip.Inflater;


public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener,
        OnMapReadyCallback {

    private TextView nameTextView;
    private TextView emailTextView;
    private ImageView userImageview;
    Marker marker;

    private FirebaseAuth auth;
    final String myUid = FirebaseAuth.getInstance().getCurrentUser().getUid();

    String name;
    private DatabaseReference mDatabaseRef;
    private ArrayList<MapList> contacts2;
    private ArrayList<String> latitude,
            longitude,
            address,
            tel,
            parkingname,
            parkingtype,
            operation,
            capacity,
            pay,
            nightFree,
            weekdayBegin,
            weekdayEnd,
            weekendBegin,
            weekendEnd,
            holidayBegin,
            holidayEnd,
            saturdayPay,
            holidayPay,
            fulltimeMonth,
            rate,
            timeRate,
            addRate,
            addtimeRate,
            dayMaximum;

    GoogleMap map;


    private FusedLocationProviderClient mFusedLocationClient;
    private int REQUEST_CODE_PERMISSIONS = 1000;

    private int PLACE_AUTOCOMPLETE_REQUEST_CODE = 100;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        latitude = new ArrayList<String>();
        longitude = new ArrayList<String>();
        address = new ArrayList<String>();
        parkingname = new ArrayList<String>();
        tel = new ArrayList<String>();
        parkingtype = new ArrayList<String>();
        operation = new ArrayList<String>();
        capacity = new ArrayList<String>();
        pay = new ArrayList<String>();
        nightFree = new ArrayList<String>();
        weekdayBegin = new ArrayList<String>();
        weekdayEnd = new ArrayList<String>();
        weekendBegin = new ArrayList<String>();
        weekendEnd = new ArrayList<String>();
        holidayBegin = new ArrayList<String>();
        holidayEnd = new ArrayList<String>();
        saturdayPay = new ArrayList<String>();
        holidayPay = new ArrayList<String>();
        fulltimeMonth = new ArrayList<String>();
        rate = new ArrayList<String>();
        timeRate = new ArrayList<String>();
        addRate = new ArrayList<String>();
        addtimeRate = new ArrayList<String>();
        dayMaximum = new ArrayList<String>();

        contacts2 = new ArrayList<MapList>();

        //NaviDrawer 영역 시작
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        //NaviDrawer 영역 끝

        //이부분에서 navigationView의 Header부분 불러옴
        View view = navigationView.getHeaderView(0);

        auth = FirebaseAuth.getInstance();


        /*권한시작*/
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},0);
        }
        /*권한끝 */

        //네비윗부분 셋팅 수정영역 시작
        userImageview = (ImageView)view.findViewById(R.id.userImageview);
        nameTextView = (TextView)view.findViewById(R.id.header_name_Textview);
        emailTextView = (TextView)view.findViewById(R.id.header_email_Textview);

        userImageview.setImageURI(auth.getCurrentUser().getPhotoUrl());
        nameTextView.setText(auth.getCurrentUser().getDisplayName());
        emailTextView.setText(auth.getCurrentUser().getEmail());
        //네비윗부분 셋팅 수정영역 끝


        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.lab1_map);
        mapFragment.getMapAsync(this);


        // 지도 객체를 얻으려면 OnMapReadyCallBack 인터페이스를 구현한 클래스를 getMapAsync() 함수를 이용하여 등록한다. 이렇게 해놓으면 지도 객체를 사용할 수 있을떄
        // onMapReady() 함수가 자동으로 호출되면서 매개변수로 GoogleMap 객체가 전달된다.


        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        PlaceAutocompleteFragment autocompleteFragment = (PlaceAutocompleteFragment)
                getFragmentManager().findFragmentById(R.id.place_autocomplete_fragment);
        EditText etPlace = (EditText) autocompleteFragment.getView().findViewById(R.id.place_autocomplete_search_input);
        ImageButton ivPlace = (ImageButton) autocompleteFragment.getView().findViewById(R.id.place_autocomplete_search_button);

        etPlace.setHint("검색할 지역을 입력하세요");
        TranslateAnimation ani = new TranslateAnimation(
                Animation.RELATIVE_TO_SELF, 1.0f,
                Animation.RELATIVE_TO_SELF, -1.0f,
                Animation.RELATIVE_TO_SELF, 0.0f,
                Animation.RELATIVE_TO_SELF, 0.0f);
        ani.setDuration(6000);
        ani.setRepeatMode(Animation.RESTART);
        ani.setRepeatCount(Animation.INFINITE);
        etPlace.startAnimation(ani);

        //etPlace.setHintTextColor(getResources().getColor(R.color.colorPrimary)); 작동안함



        /*autocompleteFragment.setOnPlaceSelectedListener(new PlaceSelectionListener() {
            @Override
            public void onPlaceSelected(Place place) {
                map.clear();
                map.moveCamera(CameraUpdateFactory.newLatLng(place.getLatLng()));

                MarkerOptions marker= new MarkerOptions();
                marker.icon(BitmapDescriptorFactory.fromResource(R.drawable.marker3));
                marker.title(place.getName().toString());// Title 마커에 표시하고 싶은 타이틀을 문자열로 설정한다.
                marker.snippet(place.getAddress().toString());//Snippet 마커에 표시되는 타이틀 바로 밑에 추가될 텍스트를 문자열로 설정한다.
                marker.alpha(0.8f); // Alpha 마커아이콘의 투명도를 설정한다. 단 타이틀이나 텍스트는 적용되지 않는다.
                map.addMarker(marker.position(place.getLatLng()));

            }

            @Override
            public void onError(Status status) {
                // TODO: Handle the error.
            }
        });*/

        etPlace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                findPlace(view);
            }
        });

        ivPlace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                findPlace(view);
            }
        });

    }

    public void findPlace(View view) {
        try {
            AutocompleteFilter typeFilter = new AutocompleteFilter.Builder().setTypeFilter(AutocompleteFilter.TYPE_FILTER_NONE).setCountry("KR").build();
            Intent intent =
                    new PlaceAutocomplete.IntentBuilder(PlaceAutocomplete.MODE_FULLSCREEN)
                            .setFilter(typeFilter)
                            .build(this);
            startActivityForResult(intent, PLACE_AUTOCOMPLETE_REQUEST_CODE);
        } catch (GooglePlayServicesRepairableException e) {
            // TODO: Handle the error.
        } catch (GooglePlayServicesNotAvailableException e) {
            // TODO: Handle the error.
        }
    }

    // A place has been received; use requestCode to track the request.
    Circle circle;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == PLACE_AUTOCOMPLETE_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                Place place = PlaceAutocomplete.getPlace(this, data);
                if (circle != null) {
                    circle.remove();
                }
                map.moveCamera(CameraUpdateFactory.newLatLng(place.getLatLng()));

                circle = map.addCircle(new CircleOptions().center(place.getLatLng()).radius(10).strokeColor(Color.BLACK).strokeWidth(2).fillColor(Color.BLUE).visible(true));


            } else if (resultCode == PlaceAutocomplete.RESULT_ERROR) {
                Status status = PlaceAutocomplete.getStatus(this, data);
                // TODO: Handle the error.

            } else if (resultCode == RESULT_CANCELED) {
                // The user canceled the operation.
            }
        }
    }
    InputStream is;
    @Override
    public void onMapReady(GoogleMap googleMap) { // 지도제어 중 가장 기본적인 제어인 지도의 중심 위치 이동을 위한 메소드


        new Thread(new Runnable() {

            @Override

            public void run() {

                getXmlData();
//                // 아래 메소드를 호출하여 XML data를 파싱해서 String 객체로 얻어오기

                runOnUiThread(new Runnable() {

                    @Override
                    public void run() {
                        for (int i = 0; i < contacts2.size(); i++) {

                            MarkerOptions apiMarkerOption = new MarkerOptions()
                                    .position(new LatLng(Double.parseDouble(latitude.get(i)), Double.parseDouble(longitude.get(i)))).visible(true);


//                            Geocoder geocoder = new Geocoder(getApplicationContext(), Locale.getDefault());
//
//                            try {
//                                List<Address> addresses  = geocoder.getFromLocation(apiMarkerOption.getPosition().latitude,apiMarkerOption.getPosition().longitude, 1);
//                            } catch (IOException e) {
//                                e.printStackTrace();
//                            }


                            Marker apiMarker = map.addMarker(apiMarkerOption);


                            apiMarker.setTag("이름" + parkingname.get(i) +
                                    "주소" + address.get(i) +
                                    "종류" + parkingtype.get(i) +
                                    "운영" + operation.get(i) +
                                    "면수" + capacity.get(i) +
                                    "유무료" + pay.get(i) +
                                    "야간유무료" + nightFree.get(i) +
                                    "평일시작" + weekdayBegin.get(i) +
                                    "평일종료" + weekdayEnd.get(i) +
                                    "주말시작" + weekendBegin.get(i) +
                                    "주말종료" + weekendEnd.get(i) +
                                    "공휴일시작" + holidayBegin.get(i) +
                                    "공휴일종료" + holidayEnd.get(i) +
                                    "토요일유무료" + saturdayPay.get(i) +
                                    "공휴일유무료" + holidayPay.get(i) +
                                    "월정기권" + fulltimeMonth.get(i) +
                                    "기본요금" + rate.get(i) +
                                    "기본시간" + timeRate.get(i) +
                                    "추가요금" + addRate.get(i) +
                                    "추가시간" + addtimeRate.get(i) +
                                    "일최대" + dayMaximum.get(i) +
                                    "번호" + tel.get(i)

                            );
                        }// TextView에 문자열  data 출력

                    }

                });
            }
        }).start();
        map = googleMap; //googleMap 객체를 얻음.

        final LatLng latLng = new LatLng(37.566643, 126.978279); // 지도내의 특정위치를 LatLng 객체로 표현. LatLng 객체에 위도, 경도를 매개변수로 줌.

        CameraPosition position = new CameraPosition.Builder().target(latLng).zoom(16f).build(); // CameraPosition 클래스는 지도가 화면에 출력되기 위한 정보를
        // 가지는 클래스로 지도의 중심 위치를 target()함수로, 지도의 확대 수준을 zoom()함수로 지정. 이렇게 만들어진 CameraPosition 을 GoogleMap 의 movecCameraag 함수의
        // 매개변수로 지정하면 CameraPosition 의 정보대로 지도에 표시된다. 위의 코드는 LatLng 객체가 표현하는 위치에 확대 수준 16의 지도를 화면에 출력한다.
        map.moveCamera(CameraUpdateFactory.newCameraPosition(position));
        // 내 위치 찍기 관련 영역
        map.setOnMyLocationButtonClickListener(onMyLocationButtonClickListener);
        map.setOnMyLocationClickListener(onMyLocationClickListener);
        map.getUiSettings().setZoomControlsEnabled(true);
        mDatabaseRef = FirebaseDatabase.getInstance().getReference("uploads");
        mDatabaseRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot s : dataSnapshot.getChildren()) {
                    Upload upload = s.getValue(Upload.class);
                    if (upload.getLat() != null) {
                        LatLng location1 = new LatLng(upload.getLat(), upload.getLon());

//                            uploadName = upload.getName();
//                            uploadLat = upload.getLat();
//                            uploadLon = upload.getLon();

                        Marker marker = map.addMarker(new MarkerOptions().position(location1).title(upload.getuserId()));
                        marker.setTag("이름" + upload.getName() + "주소" + upload.getParkingAddress() + "종류" +
                                "운영" +
                                "면수" +
                                "유무료" +
                                "야간유무료" +
                                "평일시작" +
                                "평일종료" +
                                "주말시작" +
                                "주말종료" +
                                "공휴일시작" +
                                "공휴일종료" +
                                "토요일유무료" +
                                "공휴일유무료" +
                                "월정기권" +
                                "기본요금" +
                                "기본시간" +
                                "추가요금" +
                                "추가시간" +
                                "일최대" +
                                "번호");


                    }

                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        //google map이벤트 처리 영역
        map.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            @Override
            public void onMapClick(LatLng latLng) {

            }
        });//사용자의 특정 위치클릭시 이벤트 주는 메소드
        map.setOnMapLongClickListener(new GoogleMap.OnMapLongClickListener() {
            @Override
            public void onMapLongClick(LatLng latLng) {

            }
        });// 지도의 특정 위치를 롱클릭시 이벤트 주는 메소드
        map.setOnCameraMoveListener(new GoogleMap.OnCameraMoveListener() {
            @Override
            public void onCameraMove() {

            }
        });// 사용자가 지도의 중심을 이동하거나 확대 수준을 변경하는 순간 빈번하게 이벤트 콜백 함수가
        // 호출되어 그 순간의 중심 위치 및 확대 수준을 콜백 함수로 얻을 수 있음
        map.setOnCameraIdleListener(new GoogleMap.OnCameraIdleListener() {
            @Override
            public void onCameraIdle() {

            }
        }); // 지도 변경 이벤트가 끝난 순간 한번 호출되는 이벤트


        //마커표시영역
//                final MarkerOptions markerOptions = new MarkerOptions();
//                markerOptions.icon(BitmapDescriptorFactory.fromResource(R.drawable.marker3));
//                markerOptions.position(latLng);
//                markerOptions.title("서울시청");// Title 마커에 표시하고 싶은 타이틀을 문자열로 설정한다.
//                markerOptions.snippet("tel:02-120");//Snippet 마커에 표시되는 타이틀 바로 밑에 추가될 텍스트를 문자열로 설정한다.
//                markerOptions.alpha(0.8f); // Alpha 마커아이콘의 투명도를 설정한다. 단 타이틀이나 텍스트는 적용되지 않는다.
//                map.animateCamera(CameraUpdateFactory.zoomTo(16.0f));
//                map.addMarker(markerOptions); // 마커 객체 추가

        map.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() { // 마커 클릭시 이벤트
            @Override
            public boolean onMarkerClick(final Marker marker) {
//                bottomSheet = new BottomSheetDialog();
//                bottomSheet.show(getSupportFragmentManager(), null);


                Dialog dialog = new Dialog(MainActivity.this);
                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                dialog.setContentView(R.layout.bottom_sheet);
                dialog.show();
                TextView dialogParkingName = (TextView) dialog.findViewById(R.id.dialog_ParkingName);
                TextView dialogAddress = (TextView) dialog.findViewById(R.id.dialog_Address);
                TextView dialogRate = (TextView) dialog.findViewById(R.id.dialog_Rate);
                TextView dialogTime = (TextView) dialog.findViewById(R.id.dialog_Time);

                ImageButton navi_btn = dialog.findViewById(R.id.bottom_sheet_navi_btn);
                ImageButton call_btn = dialog.findViewById(R.id.bottom_sheet_call_btn);
                ImageButton chat_btn = dialog.findViewById(R.id.bottom_sheet_chat_btn);

                final int idx1 = marker.getTag().toString().indexOf("이름");
                final int idx2 = marker.getTag().toString().indexOf("주소");
                final int idx3 = marker.getTag().toString().indexOf("종류");
                final int idx4 = marker.getTag().toString().indexOf("운영");
                final int idx5 = marker.getTag().toString().indexOf("면수");
                final int idx6 = marker.getTag().toString().indexOf("유무료");
                final int idx7 = marker.getTag().toString().indexOf("야간유무료");
                final int idx8 = marker.getTag().toString().indexOf("평일시작");
                final int idx9 = marker.getTag().toString().indexOf("평일종료");
                final int idx10 = marker.getTag().toString().indexOf("주말시작");
                final int idx11 = marker.getTag().toString().indexOf("주말종료");
                final int idx12 = marker.getTag().toString().indexOf("공휴일시작");
                final int idx13 = marker.getTag().toString().indexOf("공휴일종료");
                final int idx14 = marker.getTag().toString().indexOf("토요일유무료");
                final int idx15 = marker.getTag().toString().indexOf("공휴일유무료");
                final int idx16 = marker.getTag().toString().indexOf("월정기권");
                final int idx17 = marker.getTag().toString().indexOf("기본요금");
                final int idx18 = marker.getTag().toString().indexOf("기본시간");
                final int idx19 = marker.getTag().toString().indexOf("추가요금");
                final int idx20 = marker.getTag().toString().indexOf("추가시간");
                final int idx21 = marker.getTag().toString().indexOf("일최대");
                final int idx22 = marker.getTag().toString().indexOf("번호");


                final String TagName = marker.getTag().toString().substring(idx1 + 2, idx2);
                final String TagAddress = marker.getTag().toString().substring(idx2 + 2, idx3);
                final String TagParkingtype = marker.getTag().toString().substring(idx3 + 2, idx4);
                final String TagOperation = marker.getTag().toString().substring(idx4 + 2, idx5);
                final String TagCapacity = marker.getTag().toString().substring(idx5 + 2, idx6);
                final String TagPay = marker.getTag().toString().substring(idx6 + 3, idx7);
                final String TagNightFree = marker.getTag().toString().substring(idx7 + 5, idx8);
                final String TagWeekDayBegin = marker.getTag().toString().substring(idx8 + 4, idx8 + 6);
                final String TagWeekDayEnd = marker.getTag().toString().substring(idx9 + 4, idx9 + 6);
                final String TagWeekEndBegin = marker.getTag().toString().substring(idx10 + 4, idx11);
                final String TagWeekEndEnd = marker.getTag().toString().substring(idx11 + 4, idx12);
                final String TagHolidayBegin = marker.getTag().toString().substring(idx12 + 5, idx13);
                final String TagHolidayEnd = marker.getTag().toString().substring(idx13 + 5, idx14);
                final String TagSaturdayPay = marker.getTag().toString().substring(idx14 + 6, idx15);
                final String TagHolidayPay = marker.getTag().toString().substring(idx15 + 6, idx16);
                final String TagFulltimeMonth = marker.getTag().toString().substring(idx16 + 4, idx17);
                final String TagRate = marker.getTag().toString().substring(idx17 + 4, idx18);
                final String TagTimeRate = marker.getTag().toString().substring(idx18 + 4, idx19);
                final String TagAddRate = marker.getTag().toString().substring(idx19 + 4, idx20);
                final String TagAddtimeRate = marker.getTag().toString().substring(idx20 + 4, idx21);
                final String TagDayMaximum = marker.getTag().toString().substring(idx21 + 3, idx22);
                final String TagTel = marker.getTag().toString().substring(idx22 + 2);


                dialogParkingName.setText(TagName);
                dialogAddress.setText(TagAddress);
                if (TagTimeRate.equals("") || TagRate.equals("")) {
                    dialogRate.setText(null);
                } else {
                    dialogRate.setText(TagTimeRate + "분당" + TagRate + "원");
                }
                if (TagWeekDayBegin.equals("평일") || TagWeekDayEnd.equals("주말")) {
                    dialogTime.setText(null);
                } else {
                    dialogTime.setText(TagWeekDayBegin + "~" + TagWeekDayEnd);
                }
                navi_btn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        final String[] items = new String[]{" T map ", " 카카오 내비 ", " 아이나비 에어 "};
                        final Integer[] icons = new Integer[]{R.drawable.tmap, R.drawable.kakao_navi, R.drawable.inavi_air};
                        ListAdapter adapter = new ArrayAdapterWithIcon(MainActivity.this, items, icons);
                        new AlertDialog.Builder(MainActivity.this).setTitle("길안내를 시작할 앱을 선택해주세요")
                                .setAdapter(adapter, new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int item) {

                                        switch (item) {
                                            case 0:
                                                TMapTapi tmaptapi = new TMapTapi(MainActivity.this);
                                                tmaptapi.setSKTMapAuthentication("d163e2cf-8e08-4964-b54a-12dc3b616e63");
                                                tmaptapi.invokeRoute(marker.getTag().toString().substring(idx1 + 2, idx2), (float) marker.getPosition().longitude, (float) marker.getPosition().latitude);
                                                break;

                                            case 1:
                                                // Location.Builder를 사용하여 Location 객체를 만든다.
                                                com.kakao.kakaonavi.Location destination = com.kakao.kakaonavi.Location.newBuilder(marker.getTag().toString().substring(idx1 + 2, idx2), marker.getPosition().longitude, marker.getPosition().latitude).build();
                                                NaviOptions options = NaviOptions.newBuilder().setCoordType(CoordType.WGS84).setVehicleType(VehicleType.FIRST)
                                                        .setRpOption(RpOption.SHORTEST).build();
                                                KakaoNaviParams.Builder builder = KakaoNaviParams.newBuilder(destination).setNaviOptions(options);
                                                KakaoNaviService.navigate(MainActivity.this, builder.build());
                                                break;
                                        }
                                    }
                                }).show();


                    }
                });

                call_btn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel: 01072991337 "));
                        startActivity(intent);
                    }
                });

                chat_btn.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View view) {
                        if ( marker.getTitle().equals(myUid) ) { // ???
                            Toast.makeText(getApplicationContext(), "자신의 게시물입니다.", Toast.LENGTH_SHORT).show();
                        }else{
                            Intent intent = new Intent(view.getContext(), MessageActivity.class);
                            intent.putExtra("destinationUid", marker.getTitle()); // ???
                            startActivity(intent);
                        }
                    }
                });

                LinearLayout bottomsheetDialog = dialog.findViewById(R.id.bottom_sheet_layout);
                bottomsheetDialog.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        startActivity(new Intent(MainActivity.this, ParkingInfo.class)
                                .putExtra("TagName", TagName)
                                .putExtra("TagAddress", TagAddress)
                                .putExtra("TagParkingtype", TagParkingtype)
                                .putExtra("TagOperation", TagOperation)
                                .putExtra("TagCapacity", TagCapacity)
                                .putExtra("TagPay", TagPay)
                                .putExtra("TagNightFree", TagNightFree)
                                .putExtra("TagWeekDayBegin", TagWeekDayBegin)
                                .putExtra("TagWeekDayEnd", TagWeekDayEnd)
                                .putExtra("TagWeekEndBegin", TagWeekEndBegin)
                                .putExtra("TagWeekEndEnd", TagWeekEndEnd)
                                .putExtra("TagHolidayBegin", TagHolidayBegin)
                                .putExtra("TagHolidayEnd", TagHolidayEnd)
                                .putExtra("TagSaturdayPay", TagSaturdayPay)
                                .putExtra("TagHolidayPay", TagHolidayPay)
                                .putExtra("TagFulltimeMonth", TagFulltimeMonth)
                                .putExtra("TagRate", TagRate)
                                .putExtra("TagTimeRate", TagTimeRate)
                                .putExtra("TagAddRate", TagAddRate)
                                .putExtra("TagAddtimeRate", TagAddtimeRate)
                                .putExtra("TagDayMaximum", TagDayMaximum)
                                .putExtra("TagTel", TagTel)

                        );
                    }
                });
                return false;


            }
        });


        map.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener() { //마커의 정보창 클릭시 이벤트
            @Override
            public void onInfoWindowClick(Marker marker) {
                //..
            }
        });





        /*//주소와 위경도 변환 영역   //MyGeocodingThread 는 : 주소를 위경도로 변환, MyReverseGeocodingThread 은 : 위경도를 주소로 변환
        MyGeocodingThread thread = new MyGeocodingThread(latLng);
        thread.start();

        String address = "서울특별시 중구 서소문동 37-9";
        MyReverseGeocodingThread reverseThread = new MyReverseGeocodingThread(address);
        reverseThread.start();
        //여기까지*/


    }

    public void OnLastLocationButtonClicked(View view) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.
                checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQUEST_CODE_PERMISSIONS);
            return;
        }

        mFusedLocationClient.getLastLocation().addOnSuccessListener(this, new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if (location != null) {
//                    MarkerOptions mymarker= new MarkerOptions();
//                    mymarker.icon(BitmapDescriptorFactory.fromResource(R.drawable.marker3));
//                    mymarker.title("현재 위치");
                    LatLng myLocation = new LatLng(location.getLatitude(), location.getLongitude());
//                    map.addMarker(mymarker.position(myLocation));
                    //map.addMarker(new MarkerOptions().position(myLocation).title("현재 위치").icon(BitmapDescriptorFactory.fromResource(R.drawable.marker3)));
                    map.moveCamera(CameraUpdateFactory.newLatLng(myLocation));
                    map.animateCamera(CameraUpdateFactory.zoomTo(16.0f));
                    map.addCircle(new CircleOptions().center(myLocation).radius(10).strokeColor(Color.BLACK).strokeWidth(2).fillColor(Color.RED).visible(true));
                }
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if (ActivityCompat.checkSelfPermission(this,
                    Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.
                    checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "권한 없음", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private GoogleMap.OnMyLocationClickListener onMyLocationClickListener =
            new GoogleMap.OnMyLocationClickListener() {
                @Override
                public void onMyLocationClick(@NonNull Location location) {

                   /* map.setMinZoomPreference(12);

                    CircleOptions circleOptions = new CircleOptions();
                    circleOptions.center(new LatLng(location.getLatitude(),
                            location.getLongitude()));

                    circleOptions.radius(200);
                    circleOptions.fillColor(Color.RED);
                    circleOptions.strokeWidth(6);

                    map.addCircle(circleOptions);*/
                }
            };

    private GoogleMap.OnMyLocationButtonClickListener onMyLocationButtonClickListener =
            new GoogleMap.OnMyLocationButtonClickListener() {
                @Override
                public boolean onMyLocationButtonClick() {
                    //map.setMinZoomPreference(15);
                    return false;
                }
            };








    /*class MyReverseGeocodingThread extends Thread{
        String address;
        public MyReverseGeocodingThread(String address){
            this.address=address;
        }

        @Override
        public void run(){
            Geocoder geocoder = new Geocoder(MainActivity.this);
            try{
                List<Address> results = geocoder.getFromLocationName(address, 1);
                Address resultAddress = results.get(0);
                LatLng latLng = new LatLng(resultAddress.getLatitude(), resultAddress.getLongitude());

                Message msg = new Message();
                msg.what = 200;
                msg.obj = latLng;
                handler.sendMessage(msg);
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }

    class MyGeocodingThread extends Thread {

        LatLng latLng;

        public MyGeocodingThread(LatLng latLng){
            this.latLng = latLng;
        }

        @Override
        public void run(){
            Geocoder geocoder = new Geocoder(MainActivity.this);

            List<Address> addresses = null;
            String addressText = "";
            try {
                addresses = geocoder.getFromLocation(latLng.latitude, latLng.longitude, 1);
                Thread.sleep(500);

                if (addresses != null && addresses.size() > 0) {
                    Address address = addresses.get(0);
                    addressText = address.getAdminArea()+""+(address.getMaxAddressLineIndex() > 0 ? address.getAddressLine(0) : address.getLocality())+"";

                    String txt=address.getSubLocality();

                    if(txt != null)
                        addressText +=address.getThoroughfare() + "" + address.getSubThoroughfare();

                    Message msg = new Message();
                    msg.what = 100;
                    msg.obj = addressText;
                    handler.sendMessage(msg);
                }
            }catch (IOException e){
                e.printStackTrace();
            }catch (InterruptedException e){
                e.printStackTrace();
            }
        }
    }

    Handler handler = new Handler() {
        public void handleMessage(Message msg){
            switch (msg.what){
                case 100: {
                    Toast toast = Toast.makeText(MainActivity.this, (String)msg.obj, Toast.LENGTH_LONG);
                    toast.show();
                    break;
                }
                case 200:{

                    MarkerOptions markerOption2 = new MarkerOptions();
                    markerOption2.icon(BitmapDescriptorFactory.fromResource(R.drawable.marker2));
                    markerOption2.position((LatLng)msg.obj);
                    markerOption2.title("서울시립미술관");
                    map.addMarker(markerOption2);
                }
            }
        }
    };*/


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_camera) {
            startActivity(new Intent(MainActivity.this, AddingActivity2.class));
        } else if (id == R.id.nav_gallery) {
            startActivity(new Intent(MainActivity.this, ImagesActivity.class));
        } else if (id == R.id.nav_chat) {
            startActivity(new Intent(MainActivity.this, ChatFolderActivity.class));
        } else if (id == R.id.nav_manage) {

        } else if (id == R.id.nav_share) {

        } else if (id == R.id.nav_send) {

        } else if (id == R.id.nav_logout) {

            // Firebase sign out
            auth.signOut();
            //Facebook sign out
            LoginManager.getInstance().logOut();
            /*Google sign out
            mGoogleSignInClient.signOut();*/

            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(intent);
            Toast.makeText(MainActivity.this, "로그아웃",
                    Toast.LENGTH_SHORT).show();
            finish();

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private long time = 0;

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else if (System.currentTimeMillis() - time >= 2000) {
            time = System.currentTimeMillis();
            Toast.makeText(getApplicationContext(), "뒤로 버튼을 한번 더 누르면 종료합니다.", Toast.LENGTH_SHORT).show();
        } else if (System.currentTimeMillis() - time < 2000) {
            finish();
        }
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    public void getXmlData() {
        try {
            URL text = new URL("http://openapi.seoul.go.kr:8088/" + "634b774a5573776a37396468784355" + "/xml/GetParkInfo/1/1000"); // 파싱하고자하는 URL
            URL text2 = new URL("http://openapi.seoul.go.kr:8088/" + "634b774a5573776a37396468784355" + "/xml/GetParkInfo/1001/2000");
            URL text3 = new URL("http://openapi.seoul.go.kr:8088/" + "634b774a5573776a37396468784355" + "/xml/GetParkInfo/2001/3000");
            URL text4 = new URL("http://openapi.seoul.go.kr:8088/" + "634b774a5573776a37396468784355" + "/xml/GetParkInfo/3001/4000");
            URL text5 = new URL("http://openapi.seoul.go.kr:8088/" + "634b774a5573776a37396468784355" + "/xml/GetParkInfo/4001/5000");
            URL text6 = new URL("http://openapi.seoul.go.kr:8088/" + "634b774a5573776a37396468784355" + "/xml/GetParkInfo/5001/6000");
            URL text7 = new URL("http://openapi.seoul.go.kr:8088/" + "634b774a5573776a37396468784355" + "/xml/GetParkInfo/6001/7000");
            URL text8 = new URL("http://openapi.seoul.go.kr:8088/" + "634b774a5573776a37396468784355" + "/xml/GetParkInfo/7001/8000");
            URL text9 = new URL("http://openapi.seoul.go.kr:8088/" + "634b774a5573776a37396468784355" + "/xml/GetParkInfo/8001/9000");
            URL text10 = new URL("http://openapi.seoul.go.kr:8088/" + "634b774a5573776a37396468784355" + "/xml/GetParkInfo/9001/10000");
            URL text11 = new URL("http://openapi.seoul.go.kr:8088/" + "634b774a5573776a37396468784355" + "/xml/GetParkInfo/10001/11000");
            URL text12 = new URL("http://openapi.seoul.go.kr:8088/" + "634b774a5573776a37396468784355" + "/xml/GetParkInfo/11001/12000");
            URL text13 = new URL("http://openapi.seoul.go.kr:8088/" + "634b774a5573776a37396468784355" + "/xml/GetParkInfo/12001/13001");
            URL text14 = new URL("http://openapi.seoul.go.kr:8088/" + "634b774a5573776a37396468784355" + "/xml/GetParkInfo/13001/14000");
            URL text15 = new URL("http://openapi.seoul.go.kr:8088/" + "634b774a5573776a37396468784355" + "/xml/GetParkInfo/14001/14968");

            XmlPullParserFactory parserCreator = XmlPullParserFactory.newInstance();

            XmlPullParser parser = parserCreator.newPullParser(); // XMLPullParser 사용
            InputStream inputStream1 = text.openStream();
            InputStream inputStream2 = text2.openStream();
            InputStream inputStream3 = text3.openStream();
            InputStream inputStream4 = text4.openStream();
            InputStream inputStream5 = text5.openStream();
            InputStream inputStream6 = text6.openStream();
            InputStream inputStream7 = text7.openStream();
            InputStream inputStream8 = text8.openStream();
            InputStream inputStream9 = text9.openStream();
            InputStream inputStream10 = text10.openStream();
            InputStream inputStream11 = text11.openStream();
            InputStream inputStream12 = text12.openStream();
            InputStream inputStream13 = text13.openStream();
            InputStream inputStream14 = text14.openStream();
            InputStream inputStream15 = text15.openStream();

            InputStream streamMultiple[] = new InputStream[]{inputStream1, inputStream2, inputStream3, inputStream4, inputStream5, inputStream6, inputStream7, inputStream8, inputStream9, inputStream10, inputStream11, inputStream12, inputStream13, inputStream14, inputStream15};
            for (int i = 0; i < streamMultiple.length; i++) {
                parser.setInput(streamMultiple[i], null);   // 파싱하기위해서 스트림을 열어야한다.

                int parserEvent = parser.getEventType();  // 파싱할 데이터의 타입을 알려준다.
                String tag;

                boolean LAT = false,
                        LNG = false,
                        ADDR = false,
                        TEL = false,
                        PARKING_NAME = false,
                        PARKING_TYPE_NM = false,
                        OPERATION_RULE_NM = false,
                        CAPACITY = false,
                        PAY_NM = false,
                        NIGHT_FREE_OPEN_NM = false,
                        WEEKDAY_BEGIN_TIME = false,
                        WEEKDAY_END_TIME = false,
                        WEEKEND_BEGIN_TIME = false,
                        WEEKEND_END_TIME = false,
                        HOLIDAY_BEGIN_TIME = false,
                        HOLIDAY_END_TIME = false,
                        SATURDAY_PAY_NM = false,
                        HOLIDAY_PAY_NM = false,
                        FULLTIME_MONTHLY = false,
                        RATES = false,
                        TIME_RATE = false,
                        ADD_RATES = false,
                        ADD_TIME_RATE = false,
                        DAY_MAXIMUM = false;

                while (parserEvent != XmlPullParser.END_DOCUMENT) { // xml 파일의 문서 끝인가?
                    switch (parserEvent) {

                        case XmlPullParser.TEXT:

                            if (LAT) {
                                String max = parser.getText();
                                latitude.add(max);
                            } else if (LNG) {
                                String max = parser.getText();
                                longitude.add(max);
                            } else if (ADDR) {
                                String max = parser.getText();
                                address.add(max);
                            } else if (TEL) {
                                String max = parser.getText();
                                tel.add(max);
                            } else if (PARKING_NAME) {
                                String max = parser.getText();
                                parkingname.add(max);
                            } else if (PARKING_TYPE_NM) {
                                String max = parser.getText();
                                parkingtype.add(max);
                            } else if (OPERATION_RULE_NM) {
                                String max = parser.getText();
                                operation.add(max);
                            } else if (CAPACITY) {
                                String max = parser.getText();
                                capacity.add(max);
                            } else if (PAY_NM) {
                                String max = parser.getText();
                                pay.add(max);
                            } else if (NIGHT_FREE_OPEN_NM) {
                                String max = parser.getText();
                                nightFree.add(max);
                            } else if (WEEKDAY_BEGIN_TIME) {
                                String max = parser.getText();
                                weekdayBegin.add(max);
                            } else if (WEEKDAY_END_TIME) {
                                String max = parser.getText();
                                weekdayEnd.add(max);
                            } else if (WEEKEND_BEGIN_TIME) {
                                String max = parser.getText();
                                weekendBegin.add(max);
                            } else if (WEEKEND_END_TIME) {
                                String max = parser.getText();
                                weekendEnd.add(max);
                            } else if (HOLIDAY_BEGIN_TIME) {
                                String max = parser.getText();
                                holidayBegin.add(max);
                            } else if (HOLIDAY_END_TIME) {
                                String max = parser.getText();
                                holidayEnd.add(max);
                            } else if (SATURDAY_PAY_NM) {
                                String max = parser.getText();
                                saturdayPay.add(max);
                            } else if (HOLIDAY_PAY_NM) {
                                String max = parser.getText();
                                holidayPay.add(max);
                            } else if (FULLTIME_MONTHLY) {
                                String max = parser.getText();
                                fulltimeMonth.add(max);
                            } else if (RATES) {
                                String max = parser.getText();
                                rate.add(max);
                            } else if (TIME_RATE) {
                                String max = parser.getText();
                                timeRate.add(max);
                            } else if (ADD_RATES) {
                                String max = parser.getText();
                                addRate.add(max);
                            } else if (ADD_TIME_RATE) {
                                String max = parser.getText();
                                addtimeRate.add(max);
                            } else if (DAY_MAXIMUM) {
                                String max = parser.getText();
                                dayMaximum.add(max);
                            }

                            break;

                        case XmlPullParser.END_TAG: // 나중에
                            tag = parser.getName();

                            if (tag.equals("LAT")) {
                                LAT = false;
                            } else if (tag.equals("LNG")) {
                                LNG = false;
                            } else if (tag.equals("ADDR")) {
                                ADDR = false;
                            } else if (tag.equals("PARKING_NAME")) {
                                PARKING_NAME = false;
                            } else if (tag.equals("TEL")) {
                                TEL = false;
                            } else if (tag.equals("PARKING_TYPE_NM")) {
                                PARKING_TYPE_NM = false;
                            } else if (tag.equals("OPERATION_RULE_NM")) {
                                OPERATION_RULE_NM = false;
                            } else if (tag.equals("CAPACITY")) {
                                CAPACITY = false;
                            } else if (tag.equals("PAY_NM")) {
                                PAY_NM = false;
                            } else if (tag.equals("NIGHT_FREE_OPEN_NM")) {
                                NIGHT_FREE_OPEN_NM = false;
                            } else if (tag.equals("WEEKDAY_BEGIN_TIME")) {
                                WEEKDAY_BEGIN_TIME = false;
                            } else if (tag.equals("WEEKDAY_END_TIME")) {
                                WEEKDAY_END_TIME = false;
                            } else if (tag.equals("WEEKEND_BEGIN_TIME")) {
                                WEEKEND_BEGIN_TIME = false;
                            } else if (tag.equals("WEEKEND_END_TIME")) {
                                WEEKEND_END_TIME = false;
                            } else if (tag.equals("HOLIDAY_BEGIN_TIME")) {
                                HOLIDAY_BEGIN_TIME = false;
                            } else if (tag.equals("HOLIDAY_END_TIME")) {
                                HOLIDAY_END_TIME = false;
                            } else if (tag.equals("SATURDAY_PAY_NM")) {
                                SATURDAY_PAY_NM = false;
                            } else if (tag.equals("HOLIDAY_PAY_NM")) {
                                HOLIDAY_PAY_NM = false;
                            } else if (tag.equals("FULLTIME_MONTHLY")) {
                                FULLTIME_MONTHLY = false;
                            } else if (tag.equals("RATES")) {
                                RATES = false;
                            } else if (tag.equals("TIME_RATE")) {
                                TIME_RATE = false;
                            } else if (tag.equals("ADD_RATES")) {
                                ADD_RATES = false;
                            } else if (tag.equals("ADD_TIME_RATE")) {
                                ADD_TIME_RATE = false;
                            } else if (tag.equals("DAY_MAXIMUM")) {
                                DAY_MAXIMUM = false;
                            }

                            break;

                        case XmlPullParser.START_TAG: // 먼저
                            tag = parser.getName();

                            if (tag.equals("LAT")) {
                                LAT = true;
                            } else if (tag.equals("LNG")) {
                                LNG = true;
                            } else if (tag.equals("ADDR")) {
                                ADDR = true;
                            } else if (tag.equals("PARKING_NAME")) {
                                PARKING_NAME = true;
                            } else if (tag.equals("TEL")) {
                                TEL = true;
                            } else if (tag.equals("PARKING_TYPE_NM")) {
                                PARKING_TYPE_NM = true;
                            } else if (tag.equals("OPERATION_RULE_NM")) {
                                OPERATION_RULE_NM = true;
                            } else if (tag.equals("CAPACITY")) {
                                CAPACITY = true;
                            } else if (tag.equals("PAY_NM")) {
                                PAY_NM = true;
                            } else if (tag.equals("NIGHT_FREE_OPEN_NM")) {
                                NIGHT_FREE_OPEN_NM = true;
                            } else if (tag.equals("WEEKDAY_BEGIN_TIME")) {
                                WEEKDAY_BEGIN_TIME = true;
                            } else if (tag.equals("WEEKDAY_END_TIME")) {
                                WEEKDAY_END_TIME = true;
                            } else if (tag.equals("WEEKEND_BEGIN_TIME")) {
                                WEEKEND_BEGIN_TIME = true;
                            } else if (tag.equals("WEEKEND_END_TIME")) {
                                WEEKEND_END_TIME = true;
                            } else if (tag.equals("HOLIDAY_BEGIN_TIME")) {
                                HOLIDAY_BEGIN_TIME = true;
                            } else if (tag.equals("HOLIDAY_END_TIME")) {
                                HOLIDAY_END_TIME = true;
                            } else if (tag.equals("SATURDAY_PAY_NM")) {
                                SATURDAY_PAY_NM = true;
                            } else if (tag.equals("HOLIDAY_PAY_NM")) {
                                HOLIDAY_PAY_NM = true;
                            } else if (tag.equals("FULLTIME_MONTHLY")) {
                                FULLTIME_MONTHLY = true;
                            } else if (tag.equals("RATES")) {
                                RATES = true;
                            } else if (tag.equals("TIME_RATE")) {
                                TIME_RATE = true;
                            } else if (tag.equals("ADD_RATES")) {
                                ADD_RATES = true;
                            } else if (tag.equals("ADD_TIME_RATE")) {
                                ADD_TIME_RATE = true;
                            } else if (tag.equals("DAY_MAXIMUM")) {
                                DAY_MAXIMUM = true;
                            }
                            break;
                    }
                    parserEvent = parser.next();
                }
            }
        } catch (
                Exception e)

        {
            Log.e("dd", "Error in network call", e);
        }


        for (
                int loop = 0; loop < contacts2.size(); loop++)

        {

            contacts2.add(new MapList(latitude.get(loop),
                    longitude.get(loop),
                    address.get(loop),
                    parkingname.get(loop),
                    tel.get(loop),
                    parkingtype.get(loop),
                    operation.get(loop),
                    capacity.get(loop),
                    pay.get(loop),
                    nightFree.get(loop),
                    weekdayBegin.get(loop),
                    weekdayEnd.get(loop),
                    weekendBegin.get(loop),
                    weekendEnd.get(loop),
                    holidayBegin.get(loop),
                    holidayEnd.get(loop),
                    saturdayPay.get(loop),
                    holidayPay.get(loop),
                    fulltimeMonth.get(loop),
                    rate.get(loop),
                    timeRate.get(loop),
                    addRate.get(loop),
                    addtimeRate.get(loop),
                    dayMaximum.get(loop)
            ));
        }
    }

}
