package com.example.dlapd.seoulcarmap;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class ParkingInfo extends AppCompatActivity {
    private TextView tvName;
    private TextView tvAddress;
    private TextView tvTel;
    private TextView tvRate;
    private TextView tvTimeRate;
    private TextView tvAddRate;
    private TextView tvAddTimeRate;
    private TextView tvWeekDayBegin;
    private TextView tvWeekDayEnd;
    private TextView tvWeekEndBegin;
    private TextView tvWeekEndEnd;
    private TextView tvHolidayBegin;
    private TextView tvHolidayEnd;
    private TextView tvNightFree;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parking_info);

        tvName = (TextView) findViewById(R.id.tv_Name);
        tvAddress = (TextView) findViewById(R.id.tv_Address);
        tvTel = (TextView) findViewById(R.id.tv_Tel);
        tvRate = (TextView) findViewById(R.id.tv_Rate);
        tvTimeRate = (TextView) findViewById(R.id.tv_TimeRate);
        tvAddRate = (TextView) findViewById(R.id.tv_AddRate);
        tvAddTimeRate = (TextView) findViewById(R.id.tv_AddTimeRate);
        tvWeekDayBegin = (TextView) findViewById(R.id.tv_WeekDayBegin);
        tvWeekDayEnd = (TextView) findViewById(R.id.tv_WeekDayEnd);
        tvWeekEndBegin = (TextView) findViewById(R.id.tv_WeekEndBegin);
        tvWeekEndEnd = (TextView) findViewById(R.id.tv_WeekEndEnd);
        tvHolidayBegin = (TextView) findViewById(R.id.tv_HolidayBegin);
        tvHolidayEnd = (TextView) findViewById(R.id.tv_HolidayEnd);
        tvNightFree = (TextView) findViewById(R.id.tv_NightFree);

        Intent intent = getIntent();
        String name=intent.getStringExtra("TagName");
        String address=intent.getStringExtra("TagAddress");
        String tel=intent.getStringExtra("TagTel");
        String rate=intent.getStringExtra("TagRate");
        String timeRate=intent.getStringExtra("TagTimeRate");
        String addRate=intent.getStringExtra("TagAddRate");
        String addTimeRate=intent.getStringExtra("TagAddtimeRate");
        String weekDayBegin=intent.getStringExtra("TagWeekDayBegin");
        String weekDayEnd=intent.getStringExtra("TagWeekDayEnd");
        String weekEndBegin=intent.getStringExtra("TagWeekEndBegin");
        String weekEndEnd=intent.getStringExtra("TagWeekEndEnd");
        String holidayBegin=intent.getStringExtra("TagHolidayBegin");
        String holidayEnd=intent.getStringExtra("TagHolidayEnd");
        String nightFree=intent.getStringExtra("TagNightFree");

        if(!name.equals(""))tvName.setText(name);

        if(!address.equals(""))tvAddress.setText(address);

        if(!tel.equals(""))tvTel.setText(tel);

        if(!rate.equals(""))tvRate.setText(rate);

        if(!timeRate.equals(""))tvTimeRate.setText(timeRate);

        if(!addRate.equals(""))tvAddRate.setText(addRate);

        if(!addTimeRate.equals(""))tvAddTimeRate.setText(addTimeRate);

        if(!weekDayBegin.equals(""))tvWeekDayBegin.setText(weekDayBegin);

        if(!weekDayEnd.equals(""))tvWeekDayEnd.setText(weekDayEnd);

        if(!weekEndBegin.equals(""))tvWeekEndBegin.setText(weekEndBegin);

        if(!weekEndEnd.equals(""))tvWeekEndEnd.setText(weekEndEnd);

        if(!holidayBegin.equals(""))tvHolidayBegin.setText(holidayBegin);

        if(!holidayEnd.equals(""))tvHolidayEnd.setText(holidayEnd);

        if(!nightFree.equals(""))tvNightFree.setText(nightFree);

    }
}
