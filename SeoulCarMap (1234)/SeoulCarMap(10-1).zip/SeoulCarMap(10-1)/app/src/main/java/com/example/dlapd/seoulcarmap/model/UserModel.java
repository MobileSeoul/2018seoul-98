package com.example.dlapd.seoulcarmap.model;


public class UserModel {


    public String  muserId;
    public String  mParkingAddress;
}
