package com.example.dlapd.seoulcarmap;

public class MapList {
    private String latitude,
            longitude,
            address,
            parkingname,
            tel,
            parkingtype,
            operation,
            capacity,
            pay,
            nightFree,
            weekdayBegin,
            weekdayEnd,
            weekendBegin,
            weekendEnd,
            holidayBegin,
            holidayEnd,
            saturdayPay,
            holidayPay,
            fulltimeMonth,
            rate,
            timeRate,
            addRate,
            addtimeRate,
            dayMaximum;


    public MapList(String latitude,
                   String longtitude,
                   String address,
                   String parkingname,
                   String tel,
                   String parkingtype,
                   String operation,
                   String capacity,
                   String pay,
                   String nightFree,
                   String weekdayBegin,
                   String weekdayEnd,
                   String weekendBegin,
                   String weekendEnd,
                   String holidayBegin,
                   String holidayEnd,
                   String saturdayPay,
                   String holidayPay,
                   String fulltimeMonth,
                   String rate,
                   String timeRate,
                   String addRate,
                   String addtimeRate,
                   String dayMaximum) {

        this.latitude = latitude;
        this.longitude = longtitude;
        this.address = address;
        this.parkingname = parkingname;
        this.tel = tel;
        this.parkingtype = parkingtype;
        this.operation = parkingtype;
        this.capacity = parkingtype;
        this.pay = parkingtype;
        this.nightFree = parkingtype;
        this.weekdayBegin = parkingtype;
        this.weekdayEnd = parkingtype;
        this.weekendBegin = parkingtype;
        this.weekendEnd = parkingtype;
        this.holidayBegin = parkingtype;
        this.holidayEnd = parkingtype;
        this.saturdayPay = parkingtype;
        this.holidayPay = parkingtype;
        this.fulltimeMonth = parkingtype;
        this.rate = parkingtype;
        this.timeRate = parkingtype;
        this.addRate = parkingtype;
        this.addtimeRate = parkingtype;
        this.dayMaximum = parkingtype;

    }


    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLatitude() {
        return latitude;
    }


    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAddress() {
        return address;
    }

    public void setParkingname(String parkingname) {
        this.parkingname = parkingname;
    }

    public String getParkingname() {
        return parkingname;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getTel() {
        return tel;
    }
}