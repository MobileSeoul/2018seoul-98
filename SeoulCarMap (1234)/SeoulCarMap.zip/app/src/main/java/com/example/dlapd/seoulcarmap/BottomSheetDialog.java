package com.example.dlapd.seoulcarmap;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.media.Image;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomSheetDialogFragment;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.kakao.kakaonavi.KakaoNaviParams;
import com.kakao.kakaonavi.KakaoNaviService;
import com.kakao.kakaonavi.Location;
import com.kakao.kakaonavi.NaviOptions;
import com.kakao.kakaonavi.options.CoordType;
import com.kakao.kakaonavi.options.RpOption;
import com.kakao.kakaonavi.options.VehicleType;
import com.skt.Tmap.TMapData;
import com.skt.Tmap.TMapPoint;
import com.skt.Tmap.TMapPolyLine;
import com.skt.Tmap.TMapTapi;
import com.skt.Tmap.TMapView;

import java.util.zip.Inflater;

public class BottomSheetDialog extends BottomSheetDialogFragment {

    private ListView listView_go;
    Inflater inflater;


    @NonNull
    @Override
    public View onCreateView(final LayoutInflater inflater, @NonNull ViewGroup container, @NonNull Bundle savedInstanceState) {
        final View v = inflater.inflate(R.layout.bottom_sheet, container, false);



        ImageButton navi_btn=v.findViewById(R.id.bottom_sheet_navi_btn);
        ImageButton call_btn=v.findViewById(R.id.bottom_sheet_call_btn);

        navi_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String [] items = new String[] {" T map ", " 카카오 내비 ", " 아이나비 에어 " };
                final Integer[] icons = new Integer[] {R.drawable.tmap, R.drawable.kakao_navi, R.drawable.inavi_air};
                ListAdapter adapter = new ArrayAdapterWithIcon(getActivity(), items, icons);

                new AlertDialog.Builder(getActivity()).setTitle("길안내를 시작할 앱을 선택해주세요")
                        .setAdapter(adapter, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int item ) {

                                switch (item){

                                    case 0 :
                                        TMapTapi tmaptapi = new TMapTapi(getActivity());
                                        tmaptapi.setSKTMapAuthentication("d163e2cf-8e08-4964-b54a-12dc3b616e63");
                                        tmaptapi.invokeRoute("T타워", 126.984098f, 37.566385f);
                                        break;

                                    case 1 :
                                        // Location.Builder를 사용하여 Location 객체를 만든다.
                                        Location destination = Location.newBuilder("카카오 판교 오피스", 127.10821222694533, 37.40205604363057).build();
                                        NaviOptions options = NaviOptions.newBuilder().setCoordType(CoordType.WGS84).setVehicleType(VehicleType.FIRST)
                                                .setRpOption(RpOption.SHORTEST).build();
                                        KakaoNaviParams.Builder builder = KakaoNaviParams.newBuilder(destination).setNaviOptions(options);
                                        KakaoNaviService.navigate(getActivity(), builder.build());
                                        break;
                                }
                            }
                        }).show();


            }
        });

        call_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel: 01072991337 "));
                startActivity(intent);
            }
        });


        return v;
    }


}
