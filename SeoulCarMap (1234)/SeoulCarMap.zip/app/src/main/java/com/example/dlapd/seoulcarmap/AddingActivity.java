package com.example.dlapd.seoulcarmap;

import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.places.AutocompleteFilter;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlaceAutocomplete;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

public class AddingActivity extends AppCompatActivity implements OnMapReadyCallback {

    private static final int PICK_IMAGE_REQUEST = 1;

    /*private Button mButtonChooseImage;
    private Button mButtonUpload;
    private Button mMaps;
    private TextView mTextViewShowUploads;
    private EditText mEditTextFileName;
    private ImageView mImageView;
    private ProgressBar mProgressBar;*/

    private Button addingimageBtn;
    private Button uploadBtn;
    private EditText parkingName;
    private EditText phoneNumber;
    private EditText addressText;
    private EditText parkingSize;
    private EditText parkingCond;
    private EditText opTimeStart;
    private EditText opTimeFinish;
    private ImageView picImageView;

    private double lat;
    private double lon;

    private Uri mImageUri;

    private StorageReference mStorageRef;
    private DatabaseReference mDatabaseRef;

    private StorageTask mUploadTask;
    GoogleMap map2;
    private int PLACE_AUTOCOMPLETE_REQUEST_CODE=100;
    private FusedLocationProviderClient mFusedLocationClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.addinglayout);

        addingimageBtn = findViewById(R.id.addingimagebtn);
        uploadBtn = findViewById(R.id.uploadbtn);
        parkingName = findViewById(R.id.parkingname);
        phoneNumber = findViewById(R.id.phonenumber);
        addressText = findViewById(R.id.addresstext);
        parkingSize = findViewById(R.id.parkingsize);
        parkingCond = findViewById(R.id.parkingcond);
        opTimeStart = findViewById(R.id.optimeStart);
        opTimeFinish = findViewById(R.id.optimeFinish);
        picImageView = findViewById(R.id.picimageview);

        /*mButtonChooseImage = findViewById(R.id.button_choose_image);
        mButtonUpload = findViewById(R.id.button_upload);
        mTextViewShowUploads = findViewById(R.id.text_view_show_uploads);
        mEditTextFileName = findViewById(R.id.edit_text_file_name);
        mImageView = findViewById(R.id.image_view);
        mProgressBar = findViewById(R.id.progress_bar);
        mMaps = findViewById(R.id.button_map);*/

        mStorageRef = FirebaseStorage.getInstance().getReference("uploads");
        mDatabaseRef = FirebaseDatabase.getInstance().getReference("uploads");

        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        addingimageBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFileChooser();
            }
        });

        uploadBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mUploadTask != null && mUploadTask.isInProgress()) {
                    Toast.makeText(AddingActivity.this, "업로드중...", Toast.LENGTH_SHORT).show();
                } else {
                    uploadFile();
                    if (mUploadTask != null && mUploadTask.isInProgress()){
                        startActivity(new Intent(AddingActivity.this, MainActivity.class));
                        finish();
                    }
                }
            }
        });

        addressText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                findPlace(view);
            }
        });

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.lab2_map);
        mapFragment.getMapAsync(AddingActivity.this);

    }
    public void findPlace(View view) {
        try {
            AutocompleteFilter typeFilter = new AutocompleteFilter.Builder().setTypeFilter(AutocompleteFilter.TYPE_FILTER_NONE).setCountry("KR").build();
            Intent intent =
                    new PlaceAutocomplete.IntentBuilder(PlaceAutocomplete.MODE_FULLSCREEN)
                            .setFilter(typeFilter)
                            .build(this);
            startActivityForResult(intent, PLACE_AUTOCOMPLETE_REQUEST_CODE);
        } catch (GooglePlayServicesRepairableException e) {
            // TODO: Handle the error.
        } catch (GooglePlayServicesNotAvailableException e) {
            // TODO: Handle the error.
        }
    }
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PLACE_AUTOCOMPLETE_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                Place place = PlaceAutocomplete.getPlace(this, data);
                map2.clear();
                map2.moveCamera(CameraUpdateFactory.newLatLng(place.getLatLng()));

            } else if (resultCode == PlaceAutocomplete.RESULT_ERROR) {
                Status status = PlaceAutocomplete.getStatus(this, data);
                // TODO: Handle the error.

            } else if (resultCode == RESULT_CANCELED) {
                // The user canceled the operation.
            }
        }
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK
                && data != null && data.getData() != null) {
            mImageUri = data.getData();

            Picasso.with(this).load(mImageUri).into(picImageView);
        }
    }


    private void openFileChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }



    private String getFileExtension(Uri uri) {
        ContentResolver cR = getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cR.getType(uri));
    }

    private void uploadFile() {
        if (mImageUri != null) {
            StorageReference fileReference = mStorageRef.child(System.currentTimeMillis()
                    + "." + getFileExtension(mImageUri));

            mUploadTask = fileReference.putFile(mImageUri)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            /*Handler handler = new Handler();
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    mProgressBar.setProgress(0);
                                }
                            }, 500);*/

                            Toast.makeText(AddingActivity.this, "업로드 완료", Toast.LENGTH_LONG).show();
                            Upload upload = new Upload(parkingName.getText().toString().trim(),
                                    phoneNumber.getText().toString().trim(),
                                    addressText.getText().toString().trim(),
                                    lat,
                                    lon,
                                    parkingSize.getText().toString().trim(),
                                    parkingCond.getText().toString().trim(),
                                    opTimeStart.getText().toString().trim(),
                                    opTimeFinish.getText().toString().trim(),
                                    taskSnapshot.getDownloadUrl().toString());
                            /*Upload upload = new Upload();
                            upload.setName(parkingName.getText().toString());
                            upload.setPhoneNUmb(phoneNumber.getText().toString());
                            upload.setImageUrl(taskSnapshot.getDownloadUrl().toString());*/
                            String uploadId = mDatabaseRef.push().getKey();
                            mDatabaseRef.child(uploadId).setValue(upload);
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(AddingActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                            /*double progress = (100.0 * taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount());
                            mProgressBar.setProgress((int) progress);*/
                        }
                    });
        } else {
            Toast.makeText(this, "사진 선택하시오", Toast.LENGTH_SHORT).show();
        }
    }

    private void openImagesActivity() {
        Intent intent = new Intent(this, ImagesActivity.class);
        startActivity(intent);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        map2 = googleMap; //googleMap 객체를 얻음.

        LatLng latLng = new LatLng(37.566643, 126.978279); // 지도내의 특정위치를 LatLng 객체로 표현. LatLng 객체에 위도, 경도를 매개변수로 줌.

        CameraPosition position = new CameraPosition.Builder().target(latLng).zoom(16f).build(); // CameraPosition 클래스는 지도가 화면에 출력되기 위한 정보를
        // 가지는 클래스로 지도의 중심 위치를 target()함수로, 지도의 확대 수준을 zoom()함수로 지정. 이렇게 만들어진 CameraPosition 을 GoogleMap 의 movecCameraag 함수의
        // 매개변수로 지정하면 CameraPosition 의 정보대로 지도에 표시된다. 위의 코드는 LatLng 객체가 표현하는 위치에 확대 수준 16의 지도를 화면에 출력한다.
        map2.moveCamera(CameraUpdateFactory.newCameraPosition(position));
        // 내 위치 찍기 관련 영역
        map2.getUiSettings().setZoomControlsEnabled(true);
        map2.setOnMapClickListener(new GoogleMap.OnMapClickListener() { //포인터 위치에 마커 찍히게하기
            Marker marker;
            @Override
            public void onMapClick(final LatLng point) {

                if (marker != null) {
                    marker.remove();
                }
                marker = map2.addMarker(new MarkerOptions().icon(BitmapDescriptorFactory.fromResource(R.drawable.marker3))
                        .position(
                                new LatLng(point.latitude,
                                        point.longitude))
                        .draggable(true).visible(true));
                lat=point.latitude;
                lon=point.longitude;
                String c= String.valueOf(lat);
                String d= String.valueOf(lon);
                Toast.makeText(AddingActivity.this,c+" , "+d,Toast.LENGTH_SHORT).show();
            }
        });
    }
}
