package com.example.dlapd.seoulcarmap;

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.Signature;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.TranslateAnimation;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.places.AutocompleteFilter;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlaceAutocomplete;
import com.google.android.gms.location.places.ui.PlaceAutocompleteFragment;
import com.google.android.gms.location.places.ui.PlaceSelectionListener;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;




import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.view.Menu;
import android.view.MenuItem;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener,
        OnMapReadyCallback{



    GoogleMap map;

    private FusedLocationProviderClient mFusedLocationClient;
    private int REQUEST_CODE_PERMISSIONS = 1000;

    private int PLACE_AUTOCOMPLETE_REQUEST_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //getHashKey();

        //NaviDrawer 영역 시작
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        //NaviDrawer 영역 끝



        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.lab1_map);
        mapFragment.getMapAsync(this);


        // 지도 객체를 얻으려면 OnMapReadyCallBack 인터페이스를 구현한 클래스를 getMapAsync() 함수를 이용하여 등록한다. 이렇게 해놓으면 지도 객체를 사용할 수 있을떄
        // onMapReady() 함수가 자동으로 호출되면서 매개변수로 GoogleMap 객체가 전달된다.



        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        PlaceAutocompleteFragment autocompleteFragment = (PlaceAutocompleteFragment)
                getFragmentManager().findFragmentById(R.id.place_autocomplete_fragment);
        EditText etPlace = (EditText)autocompleteFragment.getView().findViewById(R.id.place_autocomplete_search_input);
        ImageButton ivPlace = (ImageButton)autocompleteFragment.getView().findViewById(R.id.place_autocomplete_search_button);

        etPlace.setHint("검색할 지역을 입력하세요        ");

        TranslateAnimation ani=new TranslateAnimation(
                Animation.RELATIVE_TO_SELF, 1.0f,
                Animation.RELATIVE_TO_SELF, -1.0f,
                Animation.RELATIVE_TO_SELF, 0.0f,
                Animation.RELATIVE_TO_SELF, 0.0f);
        ani.setDuration(6000);
        ani.setRepeatMode(Animation.RESTART);
        ani.setRepeatCount(Animation.INFINITE);
        etPlace.startAnimation(ani);

        //etPlace.setHintTextColor(getResources().getColor(R.color.colorPrimary)); 작동안함



        /*autocompleteFragment.setOnPlaceSelectedListener(new PlaceSelectionListener() {
            @Override
            public void onPlaceSelected(Place place) {
                map.clear();
                map.moveCamera(CameraUpdateFactory.newLatLng(place.getLatLng()));

                MarkerOptions marker= new MarkerOptions();
                marker.icon(BitmapDescriptorFactory.fromResource(R.drawable.marker3));
                marker.title(place.getName().toString());// Title 마커에 표시하고 싶은 타이틀을 문자열로 설정한다.
                marker.snippet(place.getAddress().toString());//Snippet 마커에 표시되는 타이틀 바로 밑에 추가될 텍스트를 문자열로 설정한다.
                marker.alpha(0.8f); // Alpha 마커아이콘의 투명도를 설정한다. 단 타이틀이나 텍스트는 적용되지 않는다.
                map.addMarker(marker.position(place.getLatLng()));

            }

            @Override
            public void onError(Status status) {
                // TODO: Handle the error.
            }
        });*/

    etPlace.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            findPlace(view);
        }
    });

    ivPlace.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            findPlace(view);
        }
    });
    }

    public void findPlace(View view) {
        try {
            AutocompleteFilter typeFilter = new AutocompleteFilter.Builder().setTypeFilter(AutocompleteFilter.TYPE_FILTER_NONE).setCountry("KR").build();
            Intent intent =
                    new PlaceAutocomplete.IntentBuilder(PlaceAutocomplete.MODE_FULLSCREEN)
                            .setFilter(typeFilter)
                            .build(this);
            startActivityForResult(intent, PLACE_AUTOCOMPLETE_REQUEST_CODE);
        } catch (GooglePlayServicesRepairableException e) {
            // TODO: Handle the error.
        } catch (GooglePlayServicesNotAvailableException e) {
            // TODO: Handle the error.
        }
    }

    // A place has been received; use requestCode to track the request.
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == PLACE_AUTOCOMPLETE_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                Place place = PlaceAutocomplete.getPlace(this, data);
                map.clear();
                map.moveCamera(CameraUpdateFactory.newLatLng(place.getLatLng()));

                MarkerOptions marker= new MarkerOptions();
                marker.icon(BitmapDescriptorFactory.fromResource(R.drawable.marker3));
                marker.title(place.getName().toString());// Title 마커에 표시하고 싶은 타이틀을 문자열로 설정한다.
                marker.snippet(place.getAddress().toString());//Snippet 마커에 표시되는 타이틀 바로 밑에 추가될 텍스트를 문자열로 설정한다.
                marker.alpha(0.8f); // Alpha 마커아이콘의 투명도를 설정한다. 단 타이틀이나 텍스트는 적용되지 않는다.
                map.addMarker(marker.position(place.getLatLng()));

            } else if (resultCode == PlaceAutocomplete.RESULT_ERROR) {
                Status status = PlaceAutocomplete.getStatus(this, data);
                // TODO: Handle the error.

            } else if (resultCode == RESULT_CANCELED) {
                // The user canceled the operation.
            }
        }
    }





    @Override
    public void onMapReady(GoogleMap googleMap) { // 지도제어 중 가장 기본적인 제어인 지도의 중심 위치 이동을 위한 메소드

        map = googleMap; //googleMap 객체를 얻음.

        LatLng latLng = new LatLng(37.566643, 126.978279); // 지도내의 특정위치를 LatLng 객체로 표현. LatLng 객체에 위도, 경도를 매개변수로 줌.

        CameraPosition position = new CameraPosition.Builder().target(latLng).zoom(16f).build(); // CameraPosition 클래스는 지도가 화면에 출력되기 위한 정보를
        // 가지는 클래스로 지도의 중심 위치를 target()함수로, 지도의 확대 수준을 zoom()함수로 지정. 이렇게 만들어진 CameraPosition 을 GoogleMap 의 movecCameraag 함수의
        // 매개변수로 지정하면 CameraPosition 의 정보대로 지도에 표시된다. 위의 코드는 LatLng 객체가 표현하는 위치에 확대 수준 16의 지도를 화면에 출력한다.
        map.moveCamera(CameraUpdateFactory.newCameraPosition(position));
        // 내 위치 찍기 관련 영역
        map.setOnMyLocationButtonClickListener(onMyLocationButtonClickListener);
        map.setOnMyLocationClickListener(onMyLocationClickListener);
        map.getUiSettings().setZoomControlsEnabled(true);



        //google map이벤트 처리 영역
        map.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            @Override
            public void onMapClick(LatLng latLng) {

            }
        });//사용자의 특정 위치클릭시 이벤트 주는 메소드
        map.setOnMapLongClickListener(new GoogleMap.OnMapLongClickListener() {
            @Override
            public void onMapLongClick(LatLng latLng) {

            }
        });// 지도의 특정 위치를 롱클릭시 이벤트 주는 메소드
        map.setOnCameraMoveListener(new GoogleMap.OnCameraMoveListener() {
            @Override
            public void onCameraMove() {

            }
        });// 사용자가 지도의 중심을 이동하거나 확대 수준을 변경하는 순간 빈번하게 이벤트 콜백 함수가
        // 호출되어 그 순간의 중심 위치 및 확대 수준을 콜백 함수로 얻을 수 있음
        map.setOnCameraIdleListener(new GoogleMap.OnCameraIdleListener() {
            @Override
            public void onCameraIdle() {

            }
        }); // 지도 변경 이벤트가 끝난 순간 한번 호출되는 이벤트


        //마커표시영역
        final MarkerOptions markerOptions = new MarkerOptions();
        markerOptions.icon(BitmapDescriptorFactory.fromResource(R.drawable.marker3));
        markerOptions.position(latLng);
        markerOptions.title("서울시청");// Title 마커에 표시하고 싶은 타이틀을 문자열로 설정한다.
        markerOptions.snippet("tel:02-120");//Snippet 마커에 표시되는 타이틀 바로 밑에 추가될 텍스트를 문자열로 설정한다.
        markerOptions.alpha(0.8f); // Alpha 마커아이콘의 투명도를 설정한다. 단 타이틀이나 텍스트는 적용되지 않는다.
        map.animateCamera(CameraUpdateFactory.zoomTo(16.0f));
        map.addMarker(markerOptions); // 마커 객체 추가

        map.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() { // 마커 클릭시 이벤트
            @Override
            public boolean onMarkerClick(Marker marker) {


                BottomSheetDialog bottomSheet = new BottomSheetDialog();
                bottomSheet.show(getSupportFragmentManager(), null);

                return true;

            }
        });

        map.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener() { //마커의 정보창 클릭시 이벤트
            @Override
            public void onInfoWindowClick(Marker marker) {
                //..
            }
        });





        /*//주소와 위경도 변환 영역   //MyGeocodingThread 는 : 주소를 위경도로 변환, MyReverseGeocodingThread 은 : 위경도를 주소로 변환
        MyGeocodingThread thread = new MyGeocodingThread(latLng);
        thread.start();

        String address = "서울특별시 중구 서소문동 37-9";
        MyReverseGeocodingThread reverseThread = new MyReverseGeocodingThread(address);
        reverseThread.start();
        //여기까지*/


    }

    public void OnLastLocationButtonClicked(View view) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.
                checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQUEST_CODE_PERMISSIONS);
            return;
        }

        mFusedLocationClient.getLastLocation().addOnSuccessListener(this, new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if (location != null) {
                    MarkerOptions mymarker= new MarkerOptions();
                    mymarker.icon(BitmapDescriptorFactory.fromResource(R.drawable.marker3));
                    mymarker.title("현재 위치");
                    LatLng myLocation = new LatLng(location.getLatitude(), location.getLongitude());
                    map.addMarker(mymarker.position(myLocation));
                    //map.addMarker(new MarkerOptions().position(myLocation).title("현재 위치").icon(BitmapDescriptorFactory.fromResource(R.drawable.marker3)));
                    map.moveCamera(CameraUpdateFactory.newLatLng(myLocation));
                    map.animateCamera(CameraUpdateFactory.zoomTo(16.0f));
                }
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if (ActivityCompat.checkSelfPermission(this,
                    Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.
                    checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "권한 없음", Toast.LENGTH_SHORT).show();
            }
        }
    }
    private GoogleMap.OnMyLocationClickListener onMyLocationClickListener =
            new GoogleMap.OnMyLocationClickListener() {
                @Override
                public void onMyLocationClick(@NonNull Location location) {

                   /* map.setMinZoomPreference(12);

                    CircleOptions circleOptions = new CircleOptions();
                    circleOptions.center(new LatLng(location.getLatitude(),
                            location.getLongitude()));

                    circleOptions.radius(200);
                    circleOptions.fillColor(Color.RED);
                    circleOptions.strokeWidth(6);

                    map.addCircle(circleOptions);*/
                }
            };

    private GoogleMap.OnMyLocationButtonClickListener onMyLocationButtonClickListener =
            new GoogleMap.OnMyLocationButtonClickListener() {
                @Override
                public boolean onMyLocationButtonClick() {
                    //map.setMinZoomPreference(15);
                    return false;
                }
            };








    /*class MyReverseGeocodingThread extends Thread{
        String address;
        public MyReverseGeocodingThread(String address){
            this.address=address;
        }

        @Override
        public void run(){
            Geocoder geocoder = new Geocoder(MainActivity.this);
            try{
                List<Address> results = geocoder.getFromLocationName(address, 1);
                Address resultAddress = results.get(0);
                LatLng latLng = new LatLng(resultAddress.getLatitude(), resultAddress.getLongitude());

                Message msg = new Message();
                msg.what = 200;
                msg.obj = latLng;
                handler.sendMessage(msg);
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }

    class MyGeocodingThread extends Thread {

        LatLng latLng;

        public MyGeocodingThread(LatLng latLng){
            this.latLng = latLng;
        }

        @Override
        public void run(){
            Geocoder geocoder = new Geocoder(MainActivity.this);

            List<Address> addresses = null;
            String addressText = "";
            try {
                addresses = geocoder.getFromLocation(latLng.latitude, latLng.longitude, 1);
                Thread.sleep(500);

                if (addresses != null && addresses.size() > 0) {
                    Address address = addresses.get(0);
                    addressText = address.getAdminArea()+""+(address.getMaxAddressLineIndex() > 0 ? address.getAddressLine(0) : address.getLocality())+"";

                    String txt=address.getSubLocality();

                    if(txt != null)
                        addressText +=address.getThoroughfare() + "" + address.getSubThoroughfare();

                    Message msg = new Message();
                    msg.what = 100;
                    msg.obj = addressText;
                    handler.sendMessage(msg);
                }
            }catch (IOException e){
                e.printStackTrace();
            }catch (InterruptedException e){
                e.printStackTrace();
            }
        }
    }

    Handler handler = new Handler() {
        public void handleMessage(Message msg){
            switch (msg.what){
                case 100: {
                    Toast toast = Toast.makeText(MainActivity.this, (String)msg.obj, Toast.LENGTH_LONG);
                    toast.show();
                    break;
                }
                case 200:{

                    MarkerOptions markerOption2 = new MarkerOptions();
                    markerOption2.icon(BitmapDescriptorFactory.fromResource(R.drawable.marker2));
                    markerOption2.position((LatLng)msg.obj);
                    markerOption2.title("서울시립미술관");
                    map.addMarker(markerOption2);
                }
            }
        }
    };*/

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_camera) {
            startActivity(new Intent(MainActivity.this, AddingActivity.class));
        } else if (id == R.id.nav_gallery) {
            startActivity(new Intent(MainActivity.this, ImagesActivity.class));
        } else if (id == R.id.nav_slideshow) {

        } else if (id == R.id.nav_manage) {

        } else if (id == R.id.nav_share) {

        } else if (id == R.id.nav_send) {

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
    /*private void getHashKey(){
        PackageInfo packageInfo = null;
        try {
            packageInfo = getPackageManager().getPackageInfo(getPackageName(), PackageManager.GET_SIGNATURES);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        if (packageInfo == null)
            Log.e("KeyHash", "KeyHash:null");

        for (Signature signature : packageInfo.signatures) {
            try {
                MessageDigest md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                Log.d("KeyHash", Base64.encodeToString(md.digest(), Base64.DEFAULT));
            } catch (NoSuchAlgorithmException e) {
                Log.e("KeyHash", "Unable to get MessageDigest. signature=" + signature, e);
            }
        }
    }*/
}
